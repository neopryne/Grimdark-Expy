--[[
This is the start of an ambitious project, Which aims to create a player controlled drone.
Alt to fire, ctrl for bullettime, which is only active when the drone is powered.
Bullettime is only checked for if the drone is equipped.

The drone creates drone bullets when you fire out of it.  It wraps around the screen on the player side.
It's really stupid, and not something anyone would ever want to use, so I should only do this if I really care about it.
Which I don't think I do.
]]