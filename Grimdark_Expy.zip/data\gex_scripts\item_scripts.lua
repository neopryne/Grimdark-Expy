if (not mods) then mods = {} end
mods.gex_item_template_scripts = {}
local gits = mods.gex_item_template_scripts

local lwl = mods.lightweight_lua
local lwui = mods.lightweight_user_interface
local lwsil = mods.lightweight_self_indexing_list
local ged = mods.gex_defines

gits.mEquipmentGenerationTable = {}
gits.mItemList = lwsil.SelfIndexingList:new()
local mItemList = gits.mItemList
local mEquipmentGenerationTable = gits.mEquipmentGenerationTable
local mNameToItemIndexTable = {}
local mTabbedWindow = ged.mTabbedWindow
local mTab = ged.mTab

local function NOOP() end
local ENHANCEMENTS_TAB_NAME = ged.ENHANCEMENTS_TAB_NAME
local EQUIPMENT_SUBTAB_INDEX = ged.EQUIPMENT_SUBTAB_INDEX
local TYPE_WEAPON = ged.TYPE_WEAPON
local TYPE_ARMOR = ged.TYPE_ARMOR
local TYPE_TOOL = ged.TYPE_TOOL
local EQUIPMENT_ICON_SIZE = ged.EQUIPMENT_ICON_SIZE

--Functions
local tabOneStandardVisibility = ged.tabOneStandardVisibility
--[[
This is where the scripts for the items live.
--]]

--need to convert ticks to second, and also do the omen stuff for frame rate fixing.
--This is basically a library for stat buffs that I will create and use, along with the scripts.  As ever, pull it when ready.

--todo move tick conversion to lwl actually.



--todo maybe helper functions to build items?  idk im not happy with this yet.
local function buildItemBuilder(name, itemType, renderFunction, description, onCreate, onTick)
    local generating_index = #mEquipmentGenerationTable + 1
    return function()
        local builtItem = lwui.buildItem(name, itemType, EQUIPMENT_ICON_SIZE, EQUIPMENT_ICON_SIZE,
                tabOneStandardVisibility, renderFunction, description, onCreate, onTick)
        builtItem.generating_index = generating_index
        mNameToItemIndexTable[name] = generating_index
        print("built item from index ", generating_index)
        mItemList:append(builtItem)
        return builtItem
    end
end

------------------------------------ITEM DEFINITIONS----------------------------------------------------------
--TODO need to make an array (enum) of these so I can get to them by index, the only thing I can store in a metavar.
--todo this doesn't have access to the index of the thing properly, I should just make a thing that gets and incs itself.
table.insert(mEquipmentGenerationTable, buildItemBuilder("Three-Way", TYPE_WEAPON, lwui.solidRectRenderFunction(Graphics.GL_Color(1, 1, .8, 1)), "Hit two more people at the cost of decreased damage.", NOOP, NOOP))
table.insert(mEquipmentGenerationTable, buildItemBuilder("Seal Head", TYPE_ARMOR, lwui.solidRectRenderFunction(Graphics.GL_Color(1, .8, 1, 1)), "The headbutts it enables are an effective counter to the ridicule you might encounter for wearing such odd headgear.", NOOP, NOOP))
local netgear = lwui.buildItem("Netgear", TYPE_TOOL, EQUIPMENT_ICON_SIZE, EQUIPMENT_ICON_SIZE, tabOneStandardVisibility, lwui.solidRectRenderFunction(Graphics.GL_Color(.8, 1, 1, 1)),
        "A small disk which when deployed releases entangling nets.  Also serves as a wireless access point. Cooldown: two minutes.  Deploy nets in a room to slow all movement through it for twenty five seconds by 60%.  Single use for some reason.", NOOP, NOOP)




--[[
Ballanceator armor: As all things should be.  If crew is below half health, heal them for 1
--]]


function gits.Ballanceator(item, crewmem)
    local dpt = .05
    if (crewmem:GetIntegerHealth() > crewmem:GetMaxHealth() / 2) then
        crewmem:DirectModifyHealth(-dpt)
    else
        crewmem:DirectModifyHealth(dpt)
    end
end
