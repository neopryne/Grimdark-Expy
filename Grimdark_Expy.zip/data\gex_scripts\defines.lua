if (not mods) then mods = {} end
mods.gex_defines = {}
local ged = mods.gex_defines

ged.ENHANCEMENTS_TAB_NAME = "crew_enhancements"
ged.EQUIPMENT_SUBTAB_INDEX = 1
ged.TYPE_WEAPON = "type_weapon"
ged.TYPE_ARMOR = "type_armor"
ged.TYPE_TOOL = "type_tool"
ged.EQUIPMENT_ICON_SIZE = 30


ged.mTabbedWindow = ""
ged.mTab = 1


local function generateStandardVisibilityFunction(tabName, subtabIndex)--todo move this to its own file?
    return function()
        --print(tabName, mTab, subtabIndex, mTabbedWindow)
        --return true
        return mTab == subtabIndex and mTabbedWindow == tabName
    end
end

ged.tabOneStandardVisibility = generateStandardVisibilityFunction(ENHANCEMENTS_TAB_NAME, EQUIPMENT_SUBTAB_INDEX)